import xml

from lxml import etree
import time


print('Give the full path of the xsd File')
xsdPath = input()
xmlschema_doc = etree.parse(xsdPath)
print('Give the full path of the xml File')
xmlPath = input()
start_time = time.time()

xml_doc = etree.parse(xmlPath)
xmlschema = etree.XMLSchema(xmlschema_doc)

if xmlschema.validate(xml_doc):

   print ('Valid xml')
   print("--- %s seconds ---" % (time.time() - start_time))
else:

   print ('Invalid xml')
   print("--- %s seconds ---" % (time.time() - start_time))
   xmlschema.assert_(xml_doc)





