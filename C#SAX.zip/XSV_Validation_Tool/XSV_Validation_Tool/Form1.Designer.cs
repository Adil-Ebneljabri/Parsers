﻿namespace XSV_Validation_Tool
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.xmlButt = new System.Windows.Forms.Button();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.xsvButt = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.richTextBoxResult = new System.Windows.Forms.RichTextBox();
            this.xmlNameLabel = new System.Windows.Forms.Label();
            this.xsvNameLabel = new System.Windows.Forms.Label();
            this.ValidationBut = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // xmlButt
            // 
            this.xmlButt.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.xmlButt.Location = new System.Drawing.Point(12, 68);
            this.xmlButt.Name = "xmlButt";
            this.xmlButt.Size = new System.Drawing.Size(188, 45);
            this.xmlButt.TabIndex = 0;
            this.xmlButt.Text = "Choose a XML File";
            this.xmlButt.UseVisualStyleBackColor = false;
            this.xmlButt.Click += new System.EventHandler(this.xmlButt_Click);
            // 
            // xsvButt
            // 
            this.xsvButt.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.xsvButt.Location = new System.Drawing.Point(12, 179);
            this.xsvButt.Name = "xsvButt";
            this.xsvButt.Size = new System.Drawing.Size(183, 45);
            this.xsvButt.TabIndex = 1;
            this.xsvButt.Text = "Choose a XSD File";
            this.xsvButt.UseVisualStyleBackColor = false;
            this.xsvButt.Click += new System.EventHandler(this.xsvButt_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(8, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(358, 20);
            this.label1.TabIndex = 2;
            this.label1.Text = "Choose the XML file by pressing the button below";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(8, 144);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(359, 20);
            this.label2.TabIndex = 3;
            this.label2.Text = "Choose the XSD file by pressing the button below";
            // 
            // richTextBoxResult
            // 
            this.richTextBoxResult.Location = new System.Drawing.Point(12, 243);
            this.richTextBoxResult.Name = "richTextBoxResult";
            this.richTextBoxResult.Size = new System.Drawing.Size(1641, 275);
            this.richTextBoxResult.TabIndex = 4;
            this.richTextBoxResult.Text = "";
            // 
            // xmlNameLabel
            // 
            this.xmlNameLabel.AutoSize = true;
            this.xmlNameLabel.Location = new System.Drawing.Point(217, 80);
            this.xmlNameLabel.Name = "xmlNameLabel";
            this.xmlNameLabel.Size = new System.Drawing.Size(0, 20);
            this.xmlNameLabel.TabIndex = 5;
            // 
            // xsvNameLabel
            // 
            this.xsvNameLabel.AutoSize = true;
            this.xsvNameLabel.Location = new System.Drawing.Point(217, 191);
            this.xsvNameLabel.Name = "xsvNameLabel";
            this.xsvNameLabel.Size = new System.Drawing.Size(0, 20);
            this.xsvNameLabel.TabIndex = 6;
            // 
            // ValidationBut
            // 
            this.ValidationBut.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.ValidationBut.Location = new System.Drawing.Point(1659, 243);
            this.ValidationBut.Name = "ValidationBut";
            this.ValidationBut.Size = new System.Drawing.Size(106, 45);
            this.ValidationBut.TabIndex = 7;
            this.ValidationBut.Text = "Check";
            this.ValidationBut.UseVisualStyleBackColor = false;
            this.ValidationBut.Click += new System.EventHandler(this.ValidationBut_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1777, 530);
            this.Controls.Add(this.ValidationBut);
            this.Controls.Add(this.xsvNameLabel);
            this.Controls.Add(this.xmlNameLabel);
            this.Controls.Add(this.richTextBoxResult);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.xsvButt);
            this.Controls.Add(this.xmlButt);
            this.Name = "Form1";
            this.Text = "XSV Validation Tool";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button xmlButt;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.Button xsvButt;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.RichTextBox richTextBoxResult;
        private System.Windows.Forms.Label xmlNameLabel;
        private System.Windows.Forms.Label xsvNameLabel;
        private System.Windows.Forms.Button ValidationBut;
    }
}

