﻿using System;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;
using System.Xml;
using System.Xml.Schema;

namespace XSV_Validation_Tool
{
    public partial class Form1 : Form
    {
        string xmlFileName;
        string xsdFileName;
        string xml;
        int lineNumber;
        Stopwatch stopwatch = new Stopwatch();

        public Form1()
        {
            InitializeComponent();
        }

        private void xmlButt_Click(object sender, EventArgs e)
        {
            
            

            OpenFileDialog openFileDialog1 = new OpenFileDialog
            {
                InitialDirectory = @"C:\",
                Title = "Browse XML Files",

                CheckFileExists = true,
                CheckPathExists = true,

                DefaultExt = "xml",
                Filter = "XML Files|*.xml",
                FilterIndex = 2,
                RestoreDirectory = true,

                ReadOnlyChecked = true,
                ShowReadOnly = true
            };
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                xmlFileName = openFileDialog1.FileName;
                xmlNameLabel.Text = xmlFileName;
            }

        }

        private void xsvButt_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog1 = new OpenFileDialog
            {
                InitialDirectory = @"C:\",
                Title = "Browse XSD Files",

                CheckFileExists = true,
                CheckPathExists = true,

                DefaultExt = "xsd",
                Filter = "XSD Files|*.xsd",
                FilterIndex = 2,
                RestoreDirectory = true,

                ReadOnlyChecked = true,
                ShowReadOnly = true
            };
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                xsdFileName = openFileDialog1.FileName;
                xsvNameLabel.Text = xsdFileName;
            }
        }

        private void ValidationBut_Click(object sender, EventArgs e)
        {
            stopwatch.Start();
            if (xmlFileName != null && xsdFileName != null)
            {
                XmlDocument xmlDoc = new XmlDocument();
                xmlDoc.Load(xmlFileName);
                ValidateXML(xmlFileName);
                

            }
            else
            {
                MessageBox.Show("You must select a file!");
            }
        }
        private void ValidateXML(string fileName)
        {
            xml = "";
            richTextBoxResult.Clear();
            richTextBoxResult.SelectionColor = Color.Black;
            XmlReaderSettings settings = new XmlReaderSettings();
            settings.ValidationType = ValidationType.Schema;
            settings.Schemas.Add(null, xsdFileName);

    
            settings.ValidationEventHandler += new ValidationEventHandler(this.validationEventHandler);
            XmlReader reader = XmlReader.Create(fileName, settings);
            try
            {

                while (reader.Read())
                {
                   switch (reader.NodeType)
                    {
                        case XmlNodeType.Element:
                            xml += " <" + reader.Name;
                            while (reader.MoveToNextAttribute()) 
                                xml += " " + reader.Name + "='" + reader.Value + "'";
                            xml = xml + ">";

                            break;

                        case XmlNodeType.Text: 
                            xml += reader.Value;
                            break;

                        case XmlNodeType.EndElement: 
                            xml += "</" + reader.Name + "> ";

                            break;

                        default:
                            xml += reader.Value;
                            break;
                    }
                }
                richTextBoxResult.SelectionColor = Color.Green;
                richTextBoxResult.Text = "Validation passed.";
                getTime();


            }catch (Exception ex)
            {
                IXmlLineInfo xmlInfo = (IXmlLineInfo)reader;
                lineNumber = xmlInfo.LineNumber;

                richTextBoxResult.AppendText(xml);


                richTextBoxResult.SelectionColor  = Color.Red;
                richTextBoxResult.AppendText(Environment.NewLine + "Line number : " + lineNumber);
                richTextBoxResult.AppendText(Environment.NewLine + ex.Message);
                stopwatch.Stop();
              
                getTime();




            }

        }
        private void getTime()
        {
            stopwatch.Stop();
            MessageBox.Show($"Execution Time: {stopwatch.ElapsedMilliseconds} ms");
            
        }

        private void validationEventHandler(object sender, ValidationEventArgs e)
        {
           
            throw new Exception("Validation failed. Message: "+e.Message);
         

        }
    }
}
