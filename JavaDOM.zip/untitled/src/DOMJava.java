
import java.io.File;
import java.util.Scanner;

import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Validator;

import org.w3c.dom.Document;


/**
 * @author Ranjeet.Jha
 *
 */
public class DOMJava {

    long startTime;
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Give the full path of the xsd File");
        String schemaName = scanner.nextLine();
        System.out.println("Give the full path of the xml File");
        String xmlName = scanner.nextLine();
        long startTime = System.currentTimeMillis();


        Schema schema = loadSchema(schemaName);
        Document document = parseXmlDom(xmlName);

        validateXml(schema, document);
        long endTime = System.currentTimeMillis();

        long duration = (endTime - startTime);
        System.out.println(duration);
    }

    public static void validateXml(Schema schema, Document document) {
        try {

            Validator validator = schema.newValidator();
            System.out.println("Validator Class: " + validator.getClass().getName());


            validator.validate(new DOMSource(document));
            System.out.println("Validation passed.");

        } catch (Exception e) {

            System.out.println("invalid");
            System.out.println(e.toString());

        }
    }

    public static Schema loadSchema(String schemaFileName) {
        Schema schema = null;
        try {
            String language = XMLConstants.W3C_XML_SCHEMA_NS_URI;
            SchemaFactory factory = SchemaFactory.newInstance(language);

            schema = factory.newSchema(new File(schemaFileName));
        } catch (Exception e) {
            System.out.println(e.toString());
        }
        return schema;
    }

    public static Document parseXmlDom(String xmlName) {
        Document document = null;
        try {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            document = builder.parse(new File(xmlName));
        } catch (Exception e) {
            System.out.println(e.toString());
        }
        return document;
    }

}